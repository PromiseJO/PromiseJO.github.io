<?php 

function afficherProduit(){

    $iddd = $_GET['id'];
    if(require("../config/connexion.php")){
        $req=$access->prepare("SELECT * FROM articles WHERE id = $iddd");
        $req->execute();
        $data = $req->fetchAll(PDO::FETCH_OBJ);
        return $data;
        $req->closeCursor();
    } 
    
}

$mesArticles=afficherProduit();


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/admin-header-style.css">
    <link rel="stylesheet" href="../css\page-article.css">
    <link href='https://fonts.googleapis.com/css?family=Asstistant' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Arizonia' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/818b873f46.js" crossorigin="anonymous"></script>
</head>

<body>
<?php include("admin-header.php");?> 
<div style="padding-left: 390px;">
<?php foreach($mesArticles as $Articles): ?>
                
                <figure class="article"style="padding-right:40px">
                    <img src="<?= $Articles->image ?>" >
                    <div class="contener-caption-article">
                        <h2 style="text-align:center;"><?= $Articles->titre ?></h2>
                        <p><?= $Articles->texte ?></p>
                    </div>
                </figure>
            <?php endforeach; ?> 
          </div>  
</body>
</html>