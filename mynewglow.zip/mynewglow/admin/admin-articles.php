<?php
 require("../config/commandes.php");

 $mesArticles=afficher();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/admin-articles-style.css">
    <link rel="stylesheet" href="../css/admin-header-style.css">
    <link href='https://fonts.googleapis.com/css?family=Asstistant' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Arizonia' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/818b873f46.js" crossorigin="anonymous"></script>
</head>
<body>
<?php include("admin-header.php");?>

<main>
    <div class="main">
    <div class="recherche-et-ajout">
        <div class="barre-de-recherche">
            <input type="search" placeholder="Rechercher un article">
            <button><i class="fa-solid fa-magnifying-glass"></i></button>
        </div>
        
        <button class="ajouter-un-article"><a href="ajouter-article.php">Ajouter un article</a></button>
    </div>
    <section class="section-articles">
            <div class="contener-articles-recents">
            
            <div class="articles">
            <?php foreach($mesArticles as $Articles): ?>
                <a href="page-article.php?id=<?=$idd = $Articles->id ?>">
                <figure class="article">
                    <img src="<?= $Articles->image ?>">
                    <div class="contener-caption-article">
                        <figcaption><?= $Articles->titre ?></figcaption>
                        
                    </div><a href="modifier-article.php?id=<?=$idd = $Articles->id ?>"><button>Modifier</button></a>
                </figure>
                </a>
            <?php endforeach; ?>
            </section>
    </div>
</main>
    
</body>
</html>

