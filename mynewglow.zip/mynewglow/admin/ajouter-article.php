<?php
 require("../config/commandes.php");



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/admin-header-style.css">
    <link rel="stylesheet" href="../css/modifier-article-style.css">
    <link href='https://fonts.googleapis.com/css?family=Asstistant' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Arizonia' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/818b873f46.js" crossorigin="anonymous"></script>
    <title>Document</title>
    <script src="https://cdn.tiny.cloud/1/rkeye3fje8wbywlul185wv3vt5e8y0daci1e4tl456bguv0t/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    <script>
        tinymce.init({
          selector: '#mytextarea',
          language: 'fr_FR',
          plugins: 'image',
  toolbar: 'image',
  
  image_list: [
    { title: 'My image 1', value: 'https://www.example.com/my1.gif' },
    { title: 'My image 2', value: 'http://www.moxiecode.com/my2.gif' }
  ]
        });
        
      </script>
</head>
<body>
     <?php include("admin-header.php");?> 
    <main>
    
    <div class="main"> 
    <form method="post" style=" flex-direction: colomn;">
<label for="nom-de-article" class="form-label">Titre de l'article</label>
        <input type="name" class="form-text" name="nom-de-article" required>
        
<label for="img-de-article" class="form-label">image de l'article</label>
        <input type="text" class="form-text" name="img-de-article" required>
        

        <label for="desc-de-article" class="form-label">description de l'article</label>
        <input type="textarea" class="form-text" name="desc-de-article" required>

        <label for="contenu-de-article" class="form-label">contenu de l'article</label>
        

        <textarea name="contenu-article" id="mytextarea" cols="30" rows="10"></textarea>

        <label for="date-de-article" class="form-label">date d'ajout de l'article</label>
        <input type="date" class="form-text" name="date-de-article" required>

        <label for="nom-auteur" class="form-label">auteur de l'aticle</label>
        <input type="text" class="form-text" name="nom-auteur" required>

        <label for="mots-cles-article" class="form-label">mots clés</label>
        <input type="text" class="form-text" name="mots-cles-article" required>

        <label for="categorie-de-article" class="form-label">categorie de l'article</label>
        <input type="text" class="form-text" name="categorie-de-article" required>

        <button type="submit" name="valider">Ajouter un article</button>
        
    </form>
</div>
    </main>
    
</body>
</html>

<?php 

    if(isset($_POST['valider'])){
        if(isset($_POST['nom-de-article']) AND isset($_POST['img-de-article']) AND isset($_POST['desc-de-article'])AND isset($_POST['contenu-article'])AND isset($_POST['date-de-article'])AND isset($_POST['nom-auteur'])AND isset($_POST['mots-cles-article'])AND isset($_POST['categorie-de-article']) ){
            if(!empty($_POST['nom-de-article']) AND !empty($_POST['img-de-article']) AND !empty($_POST['desc-de-article'])AND !empty($_POST['contenu-article'])AND !empty($_POST['date-de-article'])AND !empty($_POST['nom-auteur'])AND !empty($_POST['mots-cles-article'])AND !empty($_POST['categorie-de-article']) ){
                $titre = htmlspecialchars(strip_tags($_POST['nom-de-article']));
                $image = htmlspecialchars(strip_tags($_POST['img-de-article']));
                $description = htmlspecialchars(strip_tags($_POST['desc-de-article']));
                $texte = $_POST['contenu-article'];
                $date_de_publication = htmlspecialchars(strip_tags($_POST['date-de-article']));
                $auteur = htmlspecialchars(strip_tags($_POST['nom-auteur']));
                $mots_cles = htmlspecialchars(strip_tags($_POST['mots-cles-article']));
                $categorie = htmlspecialchars(strip_tags($_POST['categorie-de-article']));

                
                    ajouter($date_de_publication, $titre, $description, $image, $texte, $mots_cles, $auteur, $categorie);
            

                
            }
        }
    }

?>