  
<header>
    <div class="navigation-1">
        <h1>MyNewGlow</h1>
        <nav>
            <a href="deconnection.php"><i class="fa-solid fa-right-from-bracket"></i></a>
        </nav>
    </div>
</header>    
    <nav class="barre-de-navig-verticale">
        <ul>
            <li><a href="dashbord.php">Tableau de bord</a></li>
            <li><a href="admin-articles.php">Articles</a></li>
            <li>Calendrier</li>
            <li>Statistiques</li>
            <li>Profil</li>
            <li>Veille</li>
            <li><a href="test.php">Options</a></li>
        </ul>
    </nav>

 