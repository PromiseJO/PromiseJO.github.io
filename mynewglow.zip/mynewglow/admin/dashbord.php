






<?php
session_start();
require("../config/commandes.php");
require("../config/connexion.php"); // Include the database connection

if(!isset($_SESSION['xRttpHo0greL39'])) {
    header("Location: login.php");
}

if(empty($_SESSION['xRttpHo0greL39'])) {
    header("Location: login.php");
}

foreach($_SESSION['xRttpHo0greL39'] as $i){
  $nom = $i->pseudo;
  $email = $i->email;
}

// Database query for total articles and article frequency
$totalArticlesQuery = "SELECT COUNT(*) as total FROM articles"; // Replace 'articles' with your actual table name
$totalArticlesResult = $access->query($totalArticlesQuery);
$totalArticles = $totalArticlesResult->fetch(PDO::FETCH_ASSOC)['total'];

$articleFrequencyQuery = "SELECT DATE(date_de_publication) as date, COUNT(*) as count FROM articles GROUP BY DATE(date_de_publication)"; // Replace 'article_date' and 'articles' with your actual date column and table name
$articleFrequencyResult = $access->query($articleFrequencyQuery);

$articleData = [];
while($row = $articleFrequencyResult->fetch(PDO::FETCH_ASSOC)) {
    $articleData[] = $row;
}

// Pass data to JavaScript
echo "<script>
        var totalArticles = " . json_encode($totalArticles) . ";
        var articleData = " . json_encode($articleData) . ";
      </script>";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/admin-header-style.css">
    <link rel="stylesheet" href="../css/admin-dassbord-style.css">
    <link href='https://fonts.googleapis.com/css?family=Asstistant' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Arizonia' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/818b873f46.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script> <!-- Include Chart.js -->
    <style>
        #articleChart{max-width: 500px; max-height: 500px;}
        
    </style>
</head>
<body>  
<?php include("admin-header.php"); ?>
<main>
    <div class="main">
        <h3>Articles Totaux: <span id="totalArticles"></span></h3>
        <canvas id="articleChart" ></canvas>
    </div>
</main>
    <script>
        // Set total articles count
        document.getElementById('totalArticles').innerText = totalArticles;

        // Process article data for the chart
        var labels = articleData.map(function(data) { return data.date; });
        var dataCounts = articleData.map(function(data) { return data.count; });

        var ctx = document.getElementById('articleChart').getContext('2d');
        var articleChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'fréquence',
                    data: dataCounts,
                    backgroundColor: 'rgba(0, 123, 255, 0.5)',
                    borderColor: 'rgba(0, 123, 255, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>
