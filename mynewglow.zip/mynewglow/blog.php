<?php
require("config/commandes.php");

 
    $mesArticles = afficher();

?>


<!DOCTYPE html>
<html lang="en">
<head>





    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style-boot.css">
    <link rel="stylesheet" href="css/style.css">
    <link href='https://fonts.googleapis.com/css?family=Asstistant' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Arizonia' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/818b873f46.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/style-boot.css">


    <style>
.carousel-articles {
    display: flex;
    justify-content: space-around; /* Distributes space evenly */
    align-items: center; /* Aligns items vertically in the center */
    flex-wrap: nowrap; /* Prevents wrapping to the next line */
}

.article {
    flex: 0 0 22%; /* Flex-grow, Flex-shrink, Flex-basis */
    margin: 10px; /* Adjust as needed */
    /* Add other styling properties as required */
}

/* Responsive Design */
@media (max-width: 768px) {
    .carousel-articles {
        flex-wrap: wrap;
    }
    .article {
        flex-basis: 48%; /* Adjust for smaller screens */
    }
}




        .carousel-articles {
    display: flex;
    flex-wrap: wrap;
    gap: 20px; /* Space between cards */
}

.article {
    flex: 0 1 300px; /* Cards will have a base width of 300px but can grow and shrink */
    border: 1px solid #ccc; /* Light border */
    box-shadow: 0 4px 8px rgba(0,0,0,0.1); /* Subtle shadow */
    overflow: hidden; /* Keeps the image within the bounds of the card */
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.article:hover {
    transform: translateY(-5px); /* Slight lift effect on hover */
    box-shadow: 0 6px 12px rgba(0,0,0,0.15); /* More pronounced shadow on hover */
}

.article img {
    width: 100%; /* Full width of the card */
    height: 200px; /* Fixed height */
    object-fit: cover; /* Ensures image covers the area nicely */
    transition: transform 0.3s ease;
}

.article:hover img {
    transform: scale(1.05); /* Slight zoom effect on hover */
}

.contener-caption-article {
    padding: 10px; /* Padding around text */
}

.contener-caption-article figcaption {
    font-weight: bold; /* Make title bold */
    color: #333; /* Dark color for text */
    margin: 0; /* Remove default margins */
    font-size: 1.1em; /* Slightly larger text */
}


.search-bar {
    width: 30%; /* Adjust the width as needed */
    border: 2px solid gray; /* Add a blue border */
    padding: 10px; /* Add some padding */
    border-radius: 25px; /* Rounded corners */
    margin-top:50px;
    margin-left: 100px; /* Centering and adding margin */
    /* Display as a block */
    text-align: center; /* Center the text */
}

/* Center align blog articles */
.article {
    margin: 0 auto; /* Center the articles */
    width: 80%; /* Adjust the width as needed */
    /* other existing styles */
}
    </style>
</head>
<body>
<header>
        <h1><a href="index.php" style="color: white; text-decoration: none;">MyNewGlow</a></h1>
        <nav>
            <ul>
                <li><a href="index.php" style="color: white; text-decoration: none;">Home</a></li>
                <li><a href="blog.php" style="color: white; text-decoration: none;">Blog</a></li>
                <li>About</li>
                <li>Contact</li>
                <li><a href="admin\dashbord.php" style="color: white; text-decoration: none;"><i class="fa-solid fa-user"></i></a></li>
            </ul>
        </nav>
        
    </header style="margin-bottom:50px;">
    <body>
      <div class="input-et-button">
        <form method="POST" action="recherche-blog.php">
        <input type="search"  class="search-bar"placeholder="rechercher un article" name="recherche"><button style="padding: 10px;border-radius: 25px;" name="valider-recherche" type="submit">rechercher</button>
</div>
        
        
        
        <section class="section-articles" >

            <div class="contener-articles-recents">
                
            <div class="articles-recents" style="display: flex; flex-wrap :wrap; gap:20px;">
            <?php foreach($mesArticles as $Articles): ?>
                <a href="page-article.php?id=<?=$idd = $Articles->id ?>">
                <figure class="article">
                    <img src="<?= $Articles->image ?>">
                    <div class="contener-caption-article">
                        <figcaption><?= $Articles->titre ?></figcaption>
                        
                    </div>
                </figure>
                </a>
            <?php endforeach; ?> 
          
            </div>
</div>
            
                
            

        </section>

<!-- 
  <div class="section search-result-wrap">
    <div class="container">
      
      <div class="row posts-entry">
        <div class="col-lg-8">
        <?php foreach($mesArticles as $Articles): ?>
          <div class="blog-entry d-flex blog-entry-search-item" style="-webkit-box-shadow: 0px 0px 15px -1px rgba(0,0,0,0.5); 
box-shadow: 0px 0px 15px -1px rgba(0,0,0,0.5);">
            <a href="page-article.php?id=<?=$idd = $Articles->id ?>" class="img-link me-4">
              <img src="<?= $Articles->image ?>" alt="Image" class="img-fluid" style="object-fit: cover; height:245.53px; width:245.53px;">
            </a>
            <div>
              <span class="date">Apr. 14th, 2022 &bullet; <a href="#">Business</a></span>
              <h2><a href="page-article.php?id=<?=$idd = $Articles->id ?>"><?= $Articles->titre ?></a></h2>
              <p><?= $Articles->description ?></p>
              <p><a href="page-article.php?id=<?=$idd = $Articles->id ?>" class="btn btn-sm btn-outline-primary">Read More</a></p>
            </div>
          </div>
          <?php endforeach; ?>  -->

          <!-- <div class="blog-entry d-flex blog-entry-search-item">
            <a href="single.html" class="img-link me-4">
              <img src="images/img_2_sq.jpg" alt="Image" class="img-fluid">
            </a>
            <div>
              <span class="date">Apr. 14th, 2022 &bullet; <a href="#">Business</a></span>
              <h2><a href="single.html">Thought you loved Python? Wait until you meet Rust</a></h2>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, nobis ea quis inventore vel voluptas.</p>
              <p><a href="single.html" class="btn btn-sm btn-outline-primary">Read More</a></p>
            </div>
          </div>

          <div class="blog-entry d-flex blog-entry-search-item">
            <a href="single.html" class="img-link me-4">
              <img src="images/img_3_sq.jpg" alt="Image" class="img-fluid">
            </a>
            <div>
              <span class="date">Apr. 14th, 2022 &bullet; <a href="#">Business</a></span>
              <h2><a href="single.html">Thought you loved Python? Wait until you meet Rust</a></h2>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, nobis ea quis inventore vel voluptas.</p>
              <p><a href="single.html" class="btn btn-sm btn-outline-primary">Read More</a></p>
            </div>
          </div>

          <div class="blog-entry d-flex blog-entry-search-item">
            <a href="single.html" class="img-link me-4">
              <img src="images/img_4_sq.jpg" alt="Image" class="img-fluid">
            </a>
            <div>
              <span class="date">Apr. 14th, 2022 &bullet; <a href="#">Business</a></span>
              <h2><a href="single.html">Thought you loved Python? Wait until you meet Rust</a></h2>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, nobis ea quis inventore vel voluptas.</p>
              <p><a href="single.html" class="btn btn-sm btn-outline-primary">Read More</a></p>
            </div>
          </div>

          <div class="blog-entry d-flex blog-entry-search-item">
            <a href="single.html" class="img-link me-4">
              <img src="images/img_5_sq.jpg" alt="Image" class="img-fluid">
            </a>
            <div>
              <span class="date">Apr. 14th, 2022 &bullet; <a href="#">Business</a></span>
              <h2><a href="single.html">Thought you loved Python? Wait until you meet Rust</a></h2>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, nobis ea quis inventore vel voluptas.</p>
              <p><a href="single.html" class="btn btn-sm btn-outline-primary">Read More</a></p>
            </div>
          </div>

          <div class="row text-start pt-5 border-top">
            <div class="col-md-12">
              <div class="custom-pagination">
                <span>1</span>
                <a href="#">2</a>
                <a href="#">3</a>
                <a href="#">4</a>
                <span>...</span>
                <a href="#">15</a>
              </div>
            </div>
          </div> -->

        </div>

        
          <!-- END sidebar-box -->
         
          <!-- END sidebar-box -->

         
          <!-- END sidebar-box -->

          

        </div>
      </div>
    </div>
  </div>






        
        
        
        
        
        
        <!-- <section class="section-articles">
            <div class="contener-articles-recents">
            












            <div class="articles-recents" style="display: flex; flex-wrap: wrap; gap: 20px;">
            <?php foreach($mesArticles as $Articles): ?>
                <a href="page-article.php?id=<?=$idd = $Articles->id ?>">
                <figure class="article">
                    <img src="<?= $Articles->image ?>">
                    <div class="contener-caption-article">
                        <figcaption><?= $Articles->titre ?></figcaption>
                        <i class="fa-regular fa-heart"></i>
                    </div>
                </figure>
                </a>
            <?php endforeach; ?> 
          
            </div>
</div>
            
                
            

        </section> -->
    </body>
    <footer>

    </footer>
</body>
</html>


