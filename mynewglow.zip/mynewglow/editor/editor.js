import EditorJS from '@editorjs/editorjs';
document.addEventListener('DOMContentLoaded', () => {
    const editor = new EditorJS({
        holder: 'editorjs',
        tools: {
            header: Header,
            list: List,
            paragraph: Paragraph,
            image: ImageTool,
        },
        i18n: {
            messages: {
                // Ajoute ici tes traductions pour l'i18n
                ui: {
                    "blockTunes": {
                        "toggler": {
                            "Click to tune": "Cliquez pour ajuster",
                            "or drag to move": "ou déplacez"
                        },
                    },
                    "inlineToolbar": {
                        "converter": {
                            "Convert to": "Convertir en"
                        }
                    },
                    "toolbar": {
                        "toolbox": {
                            "Add": "Ajouter"
                        }
                    }
                },
                toolNames: {
                    "Text": "Texte",
                    "Heading": "Titre",
                    // Ajoute d'autres traductions pour les noms des outils que tu utilises
                },
                tools: {
                    // Ajoute ici tes traductions spécifiques pour chaque outil
                },
                blockTunes: {
                    // Ajoute ici tes traductions spécifiques pour chaque Block Tune
                }
            }
        },
        onReady: () => {
            console.log('Editor.js est prêt à être utilisé !');
        },
        onChange: (api, event) => {
            console.log('Le contenu de l\'éditeur a changé :', event);
        }
    });

    document.getElementById('saveButton').addEventListener('click', () => {
        editor.save()
            .then((outputData) => {
                console.log('Données de l\'article : ', outputData);
                // Envoie ces données au backend pour le traitement et l'enregistrement
                // Exemple : fetch('/api/save', { method: 'POST', body: JSON.stringify(outputData) });
            })
            .catch((error) => {
                console.log('Échec de la sauvegarde : ', error);
            });
    });
});
