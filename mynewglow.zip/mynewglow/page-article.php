<?php 

function afficherProduit(){

    $iddd = $_GET['id'];
    if(require("config/connexion.php")){
        $req=$access->prepare("SELECT * FROM articles WHERE id = $iddd");
        $req->execute();
        $data = $req->fetchAll(PDO::FETCH_OBJ);
        return $data;
        $req->closeCursor();
    } 
    
}

$mesArticles=afficherProduit();


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/page-article.css">
    <link href='https://fonts.googleapis.com/css?family=Asstistant' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Arizonia' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/818b873f46.js" crossorigin="anonymous"></script>






    <link rel="stylesheet" href="css/style-boot.css">
</head>

<body>
 <header>
        <h1><a href="index.php" style="color: white; text-decoration: none;">MyNewGlow</a></h1>
        <nav>
            <ul>
                <li><a href="index.php" style="color: white; text-decoration: none;">Home</a></li>
                <li><a href="blog.php" style="color: white; text-decoration: none;">Blog</a></li>
                <li>About</li>
                <li>Contact</li>
                <li><a href="admin\dashbord.php" style="color: white; text-decoration: none;"><i class="fa-solid fa-user"></i></a></li>
            </ul>
        </nav>
        
    </header>

    <?php foreach($mesArticles as $Articles): ?>
<div class="site-cover site-cover-sm same-height overlay single-page" style="background-image: url('<?= $Articles->image ?>');"style="object-fit: cover;">
    <div class="container">
      <div class="row same-height justify-content-center">
        <div class="col-md-6">
          <div class="post-entry text-center">
            <h1 class="mb-4"><?= $Articles->titre ?></h1>
            <div class="post-meta align-items-center text-center">
              <figure class="author-figure mb-0 me-3 d-inline-block"><img src="images/person_1.jpg" alt="Image" class="img-fluid" "></figure>
              <span class="d-inline-block mt-1">By Carl Atkinson</span>
              <span>&nbsp;-&nbsp; February 10, 2019</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <section class="section">
    <div class="container">

      <div class="row blog-entries element-animate">

        <div class="col-md-12 col-lg-8 main-content">

          <div class="post-content-body">
          <?= $Articles->texte ?>          
        </div>

          <?php endforeach; ?>

            <div class="comment-form-wrap pt-5">
              <h3 class="mb-5">Leave a comment</h3>
              <form action="#" class="p-5 bg-light">
                <div class="form-group">
                  <label for="name">Name *</label>
                  <input type="text" class="form-control" id="name">
                </div>
                <div class="form-group">
                  <label for="email">Email *</label>
                  <input type="email" class="form-control" id="email">
                </div>
                <div class="form-group">
                  <label for="website">Website</label>
                  <input type="url" class="form-control" id="website">
                </div>

                <div class="form-group">
                  <label for="message">Message</label>
                  <textarea name="" id="message" cols="30" rows="10" class="form-control"></textarea>
                </div>
                <div class="form-group">
                  <input type="submit" value="Post Comment" class="btn btn-primary">
                </div>

              </form>
            </div>
          </div>

        </div>

        <!-- END main-content -->

       

      </div>
    </div>
  </section>



<!--
<?php foreach($mesArticles as $Articles): ?>
                
                <article class="article" style="margin-top: 50px;">
                    <img src="<?= $Articles->image ?>">
                    <div class="contener-caption-article">
                        <h2><?= $Articles->titre ?></h2>
                        <p><?= $Articles->texte ?></p>
                    </div>
                </figure>
            <?php endforeach; ?>  -->
</body>
</html>