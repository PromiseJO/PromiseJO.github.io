<?php
 require("config/commandes.php");

 $mesArticles=afficherRecent();

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style-boot.css">
    <link rel="stylesheet" href="css/style.css">
    <link href='https://fonts.googleapis.com/css?family=Asstistant' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Arizonia' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/818b873f46.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/style-boot.css">

    <style>
.carousel-articles {
    display: flex;
    justify-content: space-around; /* Distributes space evenly */
    align-items: center; /* Aligns items vertically in the center */
    flex-wrap: nowrap; /* Prevents wrapping to the next line */
}

.article {
    flex: 0 0 22%; /* Flex-grow, Flex-shrink, Flex-basis */
    margin: 10px; /* Adjust as needed */
    /* Add other styling properties as required */
}

/* Responsive Design */
@media (max-width: 768px) {
    .carousel-articles {
        flex-wrap: wrap;
    }
    .article {
        flex-basis: 48%; /* Adjust for smaller screens */
    }
}




        .carousel-articles {
    display: flex;
    flex-wrap: wrap;
    gap: 20px; /* Space between cards */
}

.article {
    flex: 0 1 300px; /* Cards will have a base width of 300px but can grow and shrink */
    border: 1px solid #ccc; /* Light border */
    box-shadow: 0 4px 8px rgba(0,0,0,0.1); /* Subtle shadow */
    overflow: hidden; /* Keeps the image within the bounds of the card */
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.article:hover {
    transform: translateY(-5px); /* Slight lift effect on hover */
    box-shadow: 0 6px 12px rgba(0,0,0,0.15); /* More pronounced shadow on hover */
}

.article img {
    width: 100%; /* Full width of the card */
    height: 200px; /* Fixed height */
    object-fit: cover; /* Ensures image covers the area nicely */
    transition: transform 0.3s ease;
}

.article:hover img {
    transform: scale(1.05); /* Slight zoom effect on hover */
}

.contener-caption-article {
    padding: 10px; /* Padding around text */
}

.contener-caption-article figcaption {
    font-weight: bold; /* Make title bold */
    color: #333; /* Dark color for text */
    margin: 0; /* Remove default margins */
    font-size: 1.1em; /* Slightly larger text */
}
    </style>
</head>
<body>
    <header>
        <h1><a href="index.php" style="color: white; text-decoration: none;">MyNewGlow</a></h1>
        <nav>
            <ul>
                <li><a href="index.php" style="color: white; text-decoration: none;">Home</a></li>
                <li><a href="blog.php" style="color: white; text-decoration: none;">Blog</a></li>
                <li>About</li>
                <li>Contact</li>
                <li><a href="admin\dashbord.php" style="color: white; text-decoration: none;"><i class="fa-solid fa-user"></i></a></li>
            </ul>
        </nav>
        
    </header>
    <main style="background-color: #f8f9fa;">
        <section class="section-presentation">
            <div class="presentation">
                <h2>De nouveaux Articles tout les jours !</h2>
                <p>Bienvenue dans ce blog super cool ou vous y trouverez toujours du nouveau contenu <br> un autre paragraphe pour accrocher</p>
                <button>Explorer le blog <i class="fa-solid fa-arrow-right"></i></button>
            </div>
        </section>
        
        
        <section class="section-articles" style="opacity:1;">
        <h2 class="articles-recents-titre">Articles Récents</h2>
            <div class="contener-articles-recents">
                
            <div class="articles-recents">
                <div class="carousel-articles" id="carousel-articles">
                    <?php foreach($mesArticles as $Articles): ?>
                        
                        <figure class="article">
                            <a href="page-article.php?id=<?=$idd = $Articles->id ?>">
                            <img src="<?= $Articles->image ?>">
                            <div class="contener-caption-article">
                                <figcaption><?= $Articles->titre ?></figcaption>
                                
                            </div>
                            </a>
                        </figure>
                    
                    <?php endforeach; ?> 
                </div>
                <!-- Autres articles

                <figure class="article">
                    <img src="images\image_section_presentation.jpg">
                    <div class="contener-caption-article">
                        <figcaption>Titre de l'article</figcaption>
                        <i class="fa-regular fa-heart"></i>
                    </div>
                </figure>
            

                <figure class="article">
                    <img src="images\image_section_presentation.jpg">
                    <div class="contener-caption-article">
                        <figcaption>Titre de l'article</figcaption>
                        <i class="fa-regular fa-heart"></i>
                    </div>
                </figure>

                <figure class="article">
                    <img src="images\image_section_presentation.jpg">
                    <div class="contener-caption-article">
                        <figcaption>Titre de l'article</figcaption>
                        <i class="fa-regular fa-heart"></i>
                    </div>
                </figure>

                Fin autres articles -->

            </div>
</div>
            <!-- Articles favoris -->
           

        </section>
                    </main>
    <footer>

    </footer>
    
</body>
</html>