<?php 
    function ajouter($date_de_publication, $titre, $description, $image, $texte, $mots_cles, $auteur, $categorie){
        if(require("connexion.php")){
            $req = $access->prepare("INSERT INTO articles (date_de_publication, titre, description, image, texte, mots_cles, auteur, categorie) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            
            $req->execute(array($date_de_publication, $titre, $description, $image, $texte, $mots_cles, $auteur, $categorie));
    
            $req->closeCursor();
        }
    }

    function afficher(){
        if(require("connexion.php")){
            $req=$access->prepare("SELECT * FROM articles ORDER BY id DESC ");
            $req->execute();
            $data = $req->fetchAll(PDO::FETCH_OBJ);
            return $data;
            $req->closeCursor();
        }
    }

    function afficherRecent(){
        if(require("connexion.php")){
            $req=$access->prepare("SELECT * FROM articles ORDER BY id DESC LIMIT 3 ");
            $req->execute();
            $data = $req->fetchAll(PDO::FETCH_OBJ);
            return $data;
            $req->closeCursor();
        }
    }

    function supprimer($id){
        if(require("connexion.php")){
            $req=$access->prepare("DELETE FROM articles WHERE id=?");
            $req->execute(array($id));
        }
    }


    
function getAdmin($email, $password){
  
    if(require("connexion.php")){
  
      $req = $access->prepare("SELECT * FROM admin WHERE id=1");
  
      $req->execute();
  
      if($req->rowCount() == 1){
        
        $data = $req->fetchAll(PDO::FETCH_OBJ);
  
        foreach($data as $i){
          $mail = $i->email;
          $mdp = $i->motdepasse;
        }
  
        if($mail == $email AND $mdp == $password)
        {
          return $data;
        }
        else{
            return false;
        }
  
      }
  
    }
  
  }
    
    
?>