<?php
require("config/commandes.php");

if (isset($_POST['valider-recherche'])) {
    if (isset($_POST['recherche'])) {
        if (!empty($_POST['recherche'])) {
            $recherche = htmlspecialchars(strip_tags($_POST['recherche']));
            function recherche(){
                $recherche = htmlspecialchars(strip_tags($_POST['recherche']));
            if (require("config/connexion.php")) {
                $req = $access->prepare("SELECT * FROM articles WHERE id LIKE :recherche OR titre LIKE :recherche OR description OR categorie OR mots_cles LIKE :recherche");
                $req->execute(array(':recherche' => '%' . $recherche . '%'));
                $data = $req->fetchAll(PDO::FETCH_OBJ);
                return $data;
                $req->closeCursor();
            }}
        }
    }
}
 
    $mesArticles = recherche();

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link href='https://fonts.googleapis.com/css?family=Asstistant' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Arizonia' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/818b873f46.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/style-boot.css">
</head>
<body>
<header>
        <h1><a href="index.php" style="color: white; text-decoration: none;">MyNewGlow</a></h1>
        <nav>
            <ul>
                <li><a href="index.php" style="color: white; text-decoration: none;">Home</a></li>
                <li><a href="blog.php" style="color: white; text-decoration: none;">Blog</a></li>
                <li>About</li>
                <li>Contact</li>
                <li><a href="admin\dashbord.php" style="color: white; text-decoration: none;"><i class="fa-solid fa-user"></i></a></li>
            </ul>
        </nav>
        
    </header>
    <body>
        <form method="POST" action="recherche-blog.php">
        <input type="search" placeholder="rechercher un article" name="recherche"><button name="valider-recherche" type="submit">rechercher</button>
        <p>recherche pour "<?= $recherche;?>"</p>
        <section class="section-articles">

            <div class="contener-articles-recents">
                
            <div class="articles-recents" style="display: flex; flex-wrap :wrap; gap:20px;">
            <?php foreach($mesArticles as $Articles): ?>
                <a href="page-article.php?id=<?=$idd = $Articles->id ?>">
                <figure class="article">
                    <img src="<?= $Articles->image ?>">
                    <div class="contener-caption-article">
                        <figcaption><?= $Articles->titre ?></figcaption>
                        <i class="fa-regular fa-heart"></i>
                    </div>
                </figure>
                </a>
            <?php endforeach; ?> 
          
            </div>
</div>
            
                
            

        </section>
    </body>
    <footer>

    </footer>
</body>
</html>

